#!/bin/bash

DIR="./result"
MSGFILE="/var/log/messages"
if [ -d $DIR ]; then
	echo file here
	exit
else
	mkdir result
fi


ps -ef > $DIR/ps.txt
nmap -sT -p 1-65535 > $DIR/namp.txt
fuser 6001/tcp > $DIR/fuser.txt

echo w > $DIR/account_info.txt
w >> $DIR/account_info.txt
echo who >> $DIR/account_info.txt
who >> $DIR/account_info.txt
echo passwd >> $DIR/account_info.txt
cat /etc/passwd >> $DIR/account_info.txt

echo utmp > $DIR/logon.txt
cat /var/run/utmp >> $DIR/logon.txt
echo wtmp >> $DIR/logon.txt
cat /var/log/wtmp >> $DIR/logon.txt
echo lastlog >> $DIR/logon.txt
cat /var/log/lastlog >> $DIR/logon.txt

if [ ! -e $MSGFILE ]; then
	cat /var/log/syslog > $DIR/syslog.txt
else
	cat $MSGFILE > $DIR/message.txt
fi

ls -alct /usr/bin > $DIR/usrbin.txt
ls -alct /bin > $DIR/bin.txt

find / -ctime -10 -print -xdev > $DIR/crime10.txt
find / -user root -perm -4000 -print > $DIR/perm4000.txt
find / -user root -perm -2000 -print > $DIR/perm2000.txt
find /dev -type f -print > $DIR/cdev.txt

history > $DIR/history.txt
